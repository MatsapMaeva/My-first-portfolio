// Global State Management
const AppState = {
    currentUser: null,
    cart: JSON.parse(localStorage.getItem('cart')) || [],
    wishlist: JSON.parse(localStorage.getItem('wishlist')) || [],
    currentPage: 'home'
};

// DOM Elements
const DOM = {
    navMenu: document.getElementById('navMenu'),
    hamburger: document.getElementById('hamburger'),
    userBtn: document.getElementById('userBtn'),
    userDropdown: document.getElementById('userDropdown'),
    userMenu: document.getElementById('userMenu'),
    loginBtn: document.getElementById('loginBtn'),
    registerBtn: document.getElementById('registerBtn'),
    logoutBtn: document.getElementById('logoutBtn'),
    cartIcon: document.getElementById('cartIcon'),
    cartCount: document.querySelector('.cart-count'),
    searchInput: document.getElementById('searchInput'),
    toastContainer: document.getElementById('toastContainer'),
    loadingSpinner: document.getElementById('loadingSpinner')
};

// Initialize App
class App {
    constructor() {
        this.init();
    }

    init() {
        this.checkAuthentication();
        this.setupEventListeners();
        this.initializeAnimations();
        this.updateCartCount();
        console.log('StepStyle App Initialized');
    }

    setupEventListeners() {
        // Navigation
        if (DOM.hamburger) {
            DOM.hamburger.addEventListener('click', () => this.toggleMobileMenu());
        }

        // User dropdown
        if (DOM.userBtn) {
            DOM.userBtn.addEventListener('click', () => this.toggleUserDropdown());
        }

        // Auth buttons
        if (DOM.loginBtn) DOM.loginBtn.addEventListener('click', () => this.showLogin());
        if (DOM.registerBtn) DOM.registerBtn.addEventListener('click', () => this.showRegister());
        if (DOM.logoutBtn) DOM.logoutBtn.addEventListener('click', () => this.handleLogout());

        // Cart
        if (DOM.cartIcon) DOM.cartIcon.addEventListener('click', () => this.showCart());

        // Search
        if (DOM.searchInput) {
            DOM.searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => this.closeAllDropdowns(e));
    }

    toggleMobileMenu() {
        DOM.navMenu.classList.toggle('active');
        DOM.hamburger.classList.toggle('active');
        
        // Animate hamburger lines
        const spans = DOM.hamburger.querySelectorAll('span');
        spans.forEach((span, index) => {
            span.style.transform = DOM.navMenu.classList.contains('active') 
                ? this.getHamburgerTransform(index)
                : 'none';
        });
    }

    getHamburgerTransform(index) {
        const transforms = [
            'rotate(45deg) translate(6px, 6px)',
            'opacity(0)',
            'rotate(-45deg) translate(6px, -6px)'
        ];
        return transforms[index];
    }

    toggleUserDropdown() {
        DOM.userDropdown.classList.toggle('active');
    }

    closeAllDropdowns(e) {
        if (!e.target.closest('.user-dropdown')) {
            DOM.userDropdown.classList.remove('active');
        }
        if (!e.target.closest('.nav-menu') && !e.target.closest('.hamburger')) {
            DOM.navMenu.classList.remove('active');
            DOM.hamburger.classList.remove('active');
        }
    }

    checkAuthentication() {
        const token = localStorage.getItem('token');
        if (token) {
            AppState.currentUser = {
                name: 'John Doe',
                email: 'john@example.com'
            };
            this.updateUserInterface();
        }
    }

    updateUserInterface() {
        if (AppState.currentUser) {
            DOM.userMenu.style.display = 'block';
            DOM.loginBtn.style.display = 'none';
            DOM.registerBtn.style.display = 'none';
        } else {
            DOM.userMenu.style.display = 'none';
            DOM.loginBtn.style.display = 'block';
            DOM.registerBtn.style.display = 'block';
        }
    }

    showLogin() {
        this.showToast('Login modal would open here', 'info');
        // In a real app, show login modal
    }

    showRegister() {
        this.showToast('Register modal would open here', 'info');
        // In a real app, show register modal
    }

    handleLogout() {
        AppState.currentUser = null;
        localStorage.removeItem('token');
        this.updateUserInterface();
        this.showToast('Logged out successfully', 'success');
    }

    showCart() {
        this.showToast('Cart sidebar would open here', 'info');
        // In a real app, show cart sidebar
    }

    handleSearch(query) {
        // Global search functionality
        if (query.length > 2) {
            this.showToast(`Searching for: ${query}`, 'info');
            // In a real app, implement search logic
        }
    }

    updateCartCount() {
        const totalItems = AppState.cart.reduce((total, item) => total + item.quantity, 0);
        if (DOM.cartCount) {
            DOM.cartCount.textContent = totalItems;
            
            // Add bounce animation when count changes
            if (totalItems > 0) {
                DOM.cartCount.classList.add('animate-bounce');
                setTimeout(() => {
                    DOM.cartCount.classList.remove('animate-bounce');
                }, 1000);
            }
        }
    }

    addToCart(product) {
        if (!AppState.currentUser) {
            this.showToast('Please login to add items to cart', 'warning');
            return false;
        }

        const existingItem = AppState.cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            AppState.cart.push({
                ...product,
                quantity: 1
            });
        }
        
        localStorage.setItem('cart', JSON.stringify(AppState.cart));
        this.updateCartCount();
        this.showToast(`${product.name} added to cart`, 'success');
        
        // Add cart icon animation
        if (DOM.cartIcon) {
            DOM.cartIcon.classList.add('animate-shake');
            setTimeout(() => {
                DOM.cartIcon.classList.remove('animate-shake');
            }, 500);
        }
        
        return true;
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type} animate-slideDown`;
        toast.innerHTML = `
            <i class="fas fa-${this.getToastIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        DOM.toastContainer.appendChild(toast);
        
        // Remove toast after 4 seconds
        setTimeout(() => {
            toast.classList.add('animate-slideUp');
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, 4000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    showLoading() {
        if (DOM.loadingSpinner) {
            DOM.loadingSpinner.style.display = 'flex';
        }
    }

    hideLoading() {
        if (DOM.loadingSpinner) {
            DOM.loadingSpinner.style.display = 'none';
        }
    }

    initializeAnimations() {
        // Initialize scroll animations
        this.initScrollAnimations();
        
        // Initialize hover animations
        this.initHoverAnimations();
        
        // Initialize page transitions
        this.initPageTransitions();
    }

    initScrollAnimations() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observe all scroll-reveal elements
        document.querySelectorAll('.scroll-reveal').forEach(el => {
            observer.observe(el);
        });
    }

    initHoverAnimations() {
        // Add hover classes to interactive elements
        document.querySelectorAll('.btn, .card, .product-card').forEach(el => {
            el.classList.add('hover-lift');
        });
    }

    initPageTransitions() {
        // Smooth page transitions for navigation
        document.querySelectorAll('a[href]').forEach(link => {
            link.addEventListener('click', (e) => {
                if (link.getAttribute('href').startsWith('#')) return;
                
                const href = link.getAttribute('href');
                if (href && !href.startsWith('http') && !href.startsWith('mailto') && !href.startsWith('tel')) {
                    e.preventDefault();
                    this.navigateTo(href);
                }
            });
        });
    }

    navigateTo(url) {
        this.showLoading();
        
        // Simulate page transition
        setTimeout(() => {
            window.location.href = url;
        }, 500);
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AppState, App };
}