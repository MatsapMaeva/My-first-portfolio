// Products Module
class ProductsManager {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.displayedProducts = 12;
        this.currentFilters = {
            category: 'all',
            price: 'all',
            sort: 'newest',
            search: ''
        };
        
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.setupEventListeners();
        this.renderProducts();
        this.initializeProductAnimations();
    }

    async loadProducts() {
        // Simulate API call
        this.showLoading();
        
        try {
            // In a real app, this would be an API call
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            this.products = [
                {
                    id: 1,
                    name: "Nike Air Max 270",
                    category: "sneakers",
                    price: 129.99,
                    originalPrice: 149.99,
                    discount: 13,
                    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvZXN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60",
                    description: "Comfortable running shoes with great cushioning",
                    rating: 4.5,
                    reviewCount: 128,
                    sizes: ["8", "9", "10", "11", "12"],
                    featured: true,
                    tags: ["new", "bestseller"]
                },
                // Add more products...
            ];
            
            this.filteredProducts = [...this.products];
            this.hideLoading();
            
        } catch (error) {
            console.error('Error loading products:', error);
            this.hideLoading();
            this.showToast('Error loading products', 'error');
        }
    }

    setupEventListeners() {
        // Search
        const searchInput = document.getElementById('productsSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.currentFilters.search = e.target.value;
                this.applyFilters();
            });
        }

        // Filters
        const categoryFilter = document.getElementById('categoryFilter');
        const priceFilter = document.getElementById('priceFilter');
        const sortFilter = document.getElementById('sortFilter');

        if (categoryFilter) {
            categoryFilter.addEventListener('change', (e) => {
                this.currentFilters.category = e.target.value;
                this.applyFilters();
            });
        }

        if (priceFilter) {
            priceFilter.addEventListener('change', (e) => {
                this.currentFilters.price = e.target.value;
                this.applyFilters();
            });
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.currentFilters.sort = e.target.value;
                this.applyFilters();
            });
        }

        // Load more button
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', () => this.loadMoreProducts());
        }
    }

    applyFilters() {
        let filtered = [...this.products];

        // Search filter
        if (this.currentFilters.search) {
            const searchTerm = this.currentFilters.search.toLowerCase();
            filtered = filtered.filter(product =>
                product.name.toLowerCase().includes(searchTerm) ||
                product.description.toLowerCase().includes(searchTerm) ||
                product.category.toLowerCase().includes(searchTerm)
            );
        }

        // Category filter
        if (this.currentFilters.category !== 'all') {
            filtered = filtered.filter(product =>
                product.category === this.currentFilters.category
            );
        }

        // Price filter
        if (this.currentFilters.price !== 'all') {
            const [min, max] = this.currentFilters.price.split('-');
            if (max === '+') {
                filtered = filtered.filter(product => product.price >= parseInt(min));
            } else {
                filtered = filtered.filter(product =>
                    product.price >= parseInt(min) && product.price <= parseInt(max)
                );
            }
        }

        // Sort products
        filtered = this.sortProducts(filtered, this.currentFilters.sort);

        this.filteredProducts = filtered;
        this.displayedProducts = 12;
        this.renderProducts();
    }

    sortProducts(products, sortBy) {
        switch (sortBy) {
            case 'price-low':
                return [...products].sort((a, b) => a.price - b.price);
            case 'price-high':
                return [...products].sort((a, b) => b.price - a.price);
            case 'rating':
                return [...products].sort((a, b) => b.rating - a.rating);
            case 'newest':
            default:
                return [...products].sort((a, b) => b.id - a.id);
        }
    }

    renderProducts() {
        const productsGrid = document.getElementById('productsGrid');
        if (!productsGrid) return;

        const productsToShow = this.filteredProducts.slice(0, this.displayedProducts);

        if (productsToShow.length === 0) {
            productsGrid.innerHTML = this.getNoProductsHTML();
            return;
        }

        productsGrid.innerHTML = productsToShow.map((product, index) => `
            <div class="product-card scroll-reveal" style="animation-delay: ${index * 0.1}s">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" 
                         onerror="this.src='https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvZXN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60'">
                    
                    ${product.discount > 0 ? `
                        <div class="product-badge animate-pulse">
                            -${product.discount}% OFF
                        </div>
                    ` : ''}
                    
                    ${product.tags && product.tags.includes('new') ? `
                        <div class="product-badge" style="background: #48bb78; top: 50px;">
                            NEW
                        </div>
                    ` : ''}
                    
                    <div class="product-actions-overlay">
                        <button class="quick-view-btn" onclick="productsManager.quickView(${product.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="wishlist-btn" onclick="productsManager.addToWishlist(${product.id})">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </div>
                
                <div class="product-info">
                    <div class="product-category">${product.category}</div>
                    <h3 class="product-title">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    
                    <div class="product-rating">
                        <div class="rating-stars">
                            ${this.generateStarRating(product.rating)}
                        </div>
                        <span class="rating-count">(${product.reviewCount})</span>
                    </div>
                    
                    <div class="product-price">
                        <span class="current-price">$${product.price}</span>
                        ${product.originalPrice > product.price ? 
                            `<span class="original-price">$${product.originalPrice}</span>` : ''}
                    </div>
                    
                    <div class="product-actions">
                        <button class="btn btn-primary add-to-cart" 
                                onclick="productsManager.addToCart(${product.id})">
                            <i class="fas fa-cart-plus"></i>
                            Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        this.updateLoadMoreButton();
    }

    generateStarRating(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        
        let stars = '';
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        const emptyStars = 5 - Math.ceil(rating);
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        return stars;
    }

    getNoProductsHTML() {
        return `
            <div class="no-products scroll-reveal">
                <div class="no-products-icon">
                    <i class="fas fa-search fa-4x"></i>
                </div>
                <h3>No products found</h3>
                <p>Try adjusting your search criteria or browse different categories</p>
                <button class="btn" onclick="productsManager.resetFilters()">
                    <i class="fas fa-refresh"></i>
                    Reset Filters
                </button>
            </div>
        `;
    }

    loadMoreProducts() {
        this.displayedProducts += 12;
        this.renderProducts();
        
        // Scroll to newly loaded products
        setTimeout(() => {
            const productsGrid = document.getElementById('productsGrid');
            if (productsGrid) {
                productsGrid.scrollIntoView({ behavior: 'smooth', block: 'end' });
            }
        }, 300);
    }

    updateLoadMoreButton() {
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        if (loadMoreBtn) {
            if (this.displayedProducts >= this.filteredProducts.length) {
                loadMoreBtn.style.display = 'none';
            } else {
                loadMoreBtn.style.display = 'block';
            }
        }
    }

    quickView(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            this.showToast(`Quick view: ${product.name}`, 'info');
            // In a real app, show quick view modal
        }
    }

    addToWishlist(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            if (window.app && window.app.addToWishlist) {
                window.app.addToWishlist(product);
            } else {
                this.showToast(`${product.name} added to wishlist`, 'success');
            }
        }
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            if (window.app && window.app.addToCart) {
                const success = window.app.addToCart(product);
                if (success) {
                    // Add animation to the product card
                    const productCard = document.querySelector(`[onclick="productsManager.addToCart(${productId})"]`);
                    if (productCard) {
                        productCard.classList.add('animate-glow');
                        setTimeout(() => {
                            productCard.classList.remove('animate-glow');
                        }, 2000);
                    }
                }
            }
        }
    }

    resetFilters() {
        this.currentFilters = {
            category: 'all',
            price: 'all',
            sort: 'newest',
            search: ''
        };
        
        // Reset form elements
        const searchInput = document.getElementById('productsSearch');
        const categoryFilter = document.getElementById('categoryFilter');
        const priceFilter = document.getElementById('priceFilter');
        const sortFilter = document.getElementById('sortFilter');
        
        if (searchInput) searchInput.value = '';
        if (categoryFilter) categoryFilter.value = 'all';
        if (priceFilter) priceFilter.value = 'all';
        if (sortFilter) sortFilter.value = 'newest';
        
        this.applyFilters();
        this.showToast('Filters reset successfully', 'success');
    }

    initializeProductAnimations() {
        // Add intersection observer for product cards
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.product-card').forEach(card => {
            observer.observe(card);
        });
    }

    showLoading() {
        if (window.app) {
            window.app.showLoading();
        }
    }

    hideLoading() {
        if (window.app) {
            window.app.hideLoading();
        }
    }

    showToast(message, type) {
        if (window.app) {
            window.app.showToast(message, type);
        } else {
            console.log(`${type}: ${message}`);
        }
    }
}

// Initialize products manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.productsManager = new ProductsManager();
});