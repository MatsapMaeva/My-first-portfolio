document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('color-toggle-btn');
    const colors = [
        '#f4f4f4', // default
        '#e9c46a',
        '#f7cad0',
        '#caf0f8',
        '#d8f3dc',
        '#fff3cd',
        '#f1faee',
        '#f0efeb'
    ];
    let current = 0;
    btn.addEventListener('click', function() {
        current = (current + 1) % colors.length;
        document.body.style.backgroundColor = colors[current];
    });
    
    function showNotification(message) {
        const bar = document.getElementById('notification-bar');
        if (bar) {
            bar.textContent = message;
            bar.style.display = 'block';
            setTimeout(() => { bar.style.display = 'none'; }, 3000);
        }
    }

    // Contact form
    const form = document.getElementById('messageForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('clientName').value;
            const email = document.getElementById('clientEmail').value;
            const message = document.getElementById('clientMessage').value;
            // Simulate sending message (replace with backend integration)
            localStorage.setItem('clientMessage_' + Date.now(), JSON.stringify({name, email, message}));
            document.getElementById('messageStatus').textContent = 'Message sent! Thank you.';
            showNotification('Message sent!');
            form.reset();
        });
    }
    // Order form
    const orderForm = document.getElementById('orderForm');
    const orderStatus = document.getElementById('orderStatus');
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const checked = Array.from(document.querySelectorAll('input[name="item"]:checked'));
            if (checked.length === 0) {
                orderStatus.innerHTML = '<p>No items selected.</p>';
                return;
            }
            const items = checked.map(box => box.value + ' (1kg - 500 Ffrs)').join(', ');
            // Save order to client dashboard
            if (window.opener && window.opener.window.currentClientEmail) {
                const email = window.opener.window.currentClientEmail;
                const client = JSON.parse(localStorage.getItem('client_' + email));
                client.orders.push(items);
                localStorage.setItem('client_' + email, JSON.stringify(client));
                orderStatus.innerHTML = '<p>Order placed and added to your dashboard!</p>';
            } else {
                orderStatus.innerHTML = '<p>Order placed! (Login to see in dashboard)</p>';
            }
            orderForm.reset();
        });
    }
    // Payment form
    const paymentForm = document.getElementById('paymentForm');
    if (paymentForm) {
        paymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('paymentName').value;
            const amount = document.getElementById('paymentAmount').value;
            const date = new Date().toLocaleString();
            localStorage.setItem('clientPayment_' + Date.now(), JSON.stringify({name, amount, date}));
            document.getElementById('paymentStatus').textContent = 'Payment recorded!';
            showNotification('Payment recorded!');
            paymentForm.reset();
        });
    }
});
