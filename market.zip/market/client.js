document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('clientLoginForm');
    const loginStatus = document.getElementById('clientLoginStatus');
    const clientHistory = document.getElementById('clientHistory');
    const clientMessages = document.getElementById('clientMessages');
    const clientOrders = document.getElementById('clientOrders');
    const clientPayments = document.getElementById('clientPayments');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('clientName').value;
        loginForm.style.display = 'none';
        clientHistory.style.display = 'block';
        loginStatus.textContent = '';
        // Show messages sent by this client
        clientMessages.innerHTML = '';
        for (let key in localStorage) {
            if (key.startsWith('clientMessage_')) {
                const msg = JSON.parse(localStorage.getItem(key));
                if (msg.name === name) {
                    const li = document.createElement('li');
                    li.textContent = `${msg.message} (sent to admin)`;
                    clientMessages.appendChild(li);
                }
            }
        }
        // Show orders for this client
        clientOrders.innerHTML = '';
        for (let key in localStorage) {
            if (key.startsWith('clientOrder_')) {
                const order = JSON.parse(localStorage.getItem(key));
                if (order.name === name) {
                    const li = document.createElement('li');
                    li.textContent = `Order: ${order.items} | Date: ${order.date}`;
                    clientOrders.appendChild(li);
                }
            }
        }
        // Show payments for this client
        clientPayments.innerHTML = '';
        for (let key in localStorage) {
            if (key.startsWith('clientPayment_')) {
                const payment = JSON.parse(localStorage.getItem(key));
                if (payment.name === name) {
                    const li = document.createElement('li');
                    li.textContent = `Amount: ${payment.amount} | Date: ${payment.date}`;
                    clientPayments.appendChild(li);
                }
            }
        }
    });
});
