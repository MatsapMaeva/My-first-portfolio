document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    const loginForm = document.getElementById('loginForm');
    const authStatus = document.getElementById('authStatus');
    const dashboard = document.getElementById('client-dashboard');
    const clientNameSpan = document.getElementById('clientName');

    // Registration
        // Utility: SHA-256 hash
        async function hashPassword(password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
        }

        // Entry buttons
        window.showAdminLogin = function() {
            hideAllSections();
            document.getElementById('admin-login').style.display = 'block';
        };
        window.showClientLogin = function() {
            hideAllSections();
            document.getElementById('client-login').style.display = 'block';
        };
        window.showClientRegister = function() {
            hideAllSections();
            document.getElementById('client-register').style.display = 'block';
        };

        function hideAllSections() {
            document.getElementById('dashboard-entry').style.display = 'none';
            document.getElementById('admin-login').style.display = 'none';
            document.getElementById('admin-dashboard').style.display = 'none';
            document.getElementById('client-login').style.display = 'none';
            document.getElementById('client-register').style.display = 'none';
            document.getElementById('client-dashboard').style.display = 'none';
        }

        // Admin login
        const adminLoginForm = document.getElementById('adminLoginForm');
        if (adminLoginForm) {
            adminLoginForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                const user = document.getElementById('adminUser').value;
                const pass = document.getElementById('adminPass').value;
                const ADMIN_USER = 'admin';
                const ADMIN_PASS_HASH = await hashPassword('admin123');
                const inputHash = await hashPassword(pass);
                if (user === ADMIN_USER && inputHash === ADMIN_PASS_HASH) {
                    hideAllSections();
                    document.getElementById('admin-dashboard').style.display = 'block';
                    document.getElementById('adminLoginStatus').textContent = '';
                    // Render all clients
                    let clientsHtml = '<h3>Clients</h3><ul>';
                    for (let key in localStorage) {
                        if (key.startsWith('client_')) {
                            const client = JSON.parse(localStorage.getItem(key));
                            clientsHtml += `<li>${client.name} (${client.email}, ${client.city})</li>`;
                        }
                    }
                    clientsHtml += '</ul>';
                    // Render all orders
                    let ordersHtml = '<h3>Orders</h3><ul>';
                    for (let key in localStorage) {
                        if (key.startsWith('client_')) {
                            const client = JSON.parse(localStorage.getItem(key));
                            (client.orders || []).forEach(order => {
                                ordersHtml += `<li>${client.name}: ${order}</li>`;
                            });
                        }
                    }
                    ordersHtml += '</ul>';
                    // Render all messages
                    let messagesHtml = '<h3>Messages</h3><ul>';
                    for (let key in localStorage) {
                        if (key.startsWith('clientMessage_')) {
                            const msg = JSON.parse(localStorage.getItem(key));
                            messagesHtml += `<li>${msg.name} (${msg.email}): ${msg.message}</li>`;
                        }
                    }
                    messagesHtml += '</ul>';
                    // Inject into admin-dashboard
                    document.getElementById('admin-dashboard').innerHTML = `
                        <h2>Admin Services</h2>
                        ${clientsHtml}
                        ${ordersHtml}
                        ${messagesHtml}
                        <button onclick="logoutAdmin()">Logout</button>
                    `;
                } else {
                    document.getElementById('adminLoginStatus').textContent = 'Invalid credentials!';
                }
            });
        }
        window.logoutAdmin = function() {
            hideAllSections();
            document.getElementById('dashboard-entry').style.display = 'block';
        };

        // Client login
        if (loginForm) {
            loginForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                const email = document.getElementById('loginEmail').value;
                const pass = document.getElementById('loginPass').value;
                const client = JSON.parse(localStorage.getItem('client_' + email));
                const inputHash = await hashPassword(pass);
                if (!client || client.pass !== inputHash) {
                    document.getElementById('clientLoginStatus').textContent = 'Invalid email or password.';
                    return;
                }
                document.getElementById('clientLoginStatus').textContent = 'Login successful!';
                setTimeout(() => loginClient(client.name, email), 1000);
                loginForm.reset();
            });
        }

        // Client registration
        if (registerForm) {
            registerForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                const name = document.getElementById('regName').value;
                const email = document.getElementById('regEmail').value;
                const pass = document.getElementById('regPass').value;
                const city = document.getElementById('regCity').value;
                if (localStorage.getItem('client_' + email)) {
                    document.getElementById('clientRegisterStatus').textContent = 'Account already exists. Please login.';
                    return;
                }
                const passHash = await hashPassword(pass);
                localStorage.setItem('client_' + email, JSON.stringify({name, email, pass: passHash, city, orders: [], payments: []}));
                document.getElementById('clientRegisterStatus').textContent = 'Registration successful! Logging you in...';
                setTimeout(() => loginClient(name, email), 1000);
                registerForm.reset();
            });
        }

        // Show client dashboard
        function loginClient(name, email) {
            hideAllSections();
            document.getElementById('client-dashboard').style.display = 'block';
            document.getElementById('clientName').textContent = name;
            // Show order and payment history
            const client = JSON.parse(localStorage.getItem('client_' + email));
            let orderHtml = '<h3>Your Orders</h3><ul>';
            (client.orders || []).forEach(o => { orderHtml += `<li>${o}</li>`; });
            orderHtml += '</ul>';
            document.getElementById('orderHistory').innerHTML = orderHtml;
            let payHtml = '<h3>Your Payments</h3><ul>';
            (client.payments || []).forEach(p => { payHtml += `<li>${p}</li>`; });
            payHtml += '</ul>';
            document.getElementById('paymentHistory').innerHTML = payHtml;
            window.currentClientEmail = email;
        }

        window.logoutClient = function() {
            hideAllSections();
            document.getElementById('dashboard-entry').style.display = 'block';
        };

        // On load, show dashboard entry
        hideAllSections();
        document.getElementById('dashboard-entry').style.display = 'block';

    // Login
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const pass = document.getElementById('loginPass').value;
        const client = JSON.parse(localStorage.getItem('client_' + email));
        if (!client || client.pass !== pass) {
            authStatus.textContent = 'Invalid email or password.';
            return;
        }
        authStatus.textContent = 'Login successful!';
        setTimeout(() => loginClient(client.name, email), 1000);
        loginForm.reset();
    });

    // Show dashboard
    function loginClient(name, email) {
        document.getElementById('auth-section').style.display = 'none';
        dashboard.style.display = 'block';
        clientNameSpan.textContent = name;
        // Show order and payment history
        const client = JSON.parse(localStorage.getItem('client_' + email));
        let orderHtml = '<h3>Your Orders</h3><ul>';
        client.orders.forEach(o => { orderHtml += `<li>${o}</li>`; });
        orderHtml += '</ul>';
        document.getElementById('orderHistory').innerHTML = orderHtml;
        let payHtml = '<h3>Your Payments</h3><ul>';
        client.payments.forEach(p => { payHtml += `<li>${p}</li>`; });
        payHtml += '</ul>';
        document.getElementById('paymentHistory').innerHTML = payHtml;
        window.currentClientEmail = email;
    }

    // Logout
    window.logoutClient = function() {
        dashboard.style.display = 'none';
        document.getElementById('auth-section').style.display = 'block';
        authStatus.textContent = 'Logged out.';
    };
});
