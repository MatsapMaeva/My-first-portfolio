document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('adminLoginForm');
    const dashboard = document.getElementById('admin-dashboard');
    const loginStatus = document.getElementById('adminLoginStatus');
    const adminClients = document.getElementById('adminClients');
    const adminOrders = document.getElementById('adminOrders');
    const adminMessages = document.getElementById('adminMessages');
    // Hardcoded admin credentials
    const ADMIN_USER = 'admin';
    const ADMIN_PASS = 'admin123';

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const user = document.getElementById('adminUser').value;
        const pass = document.getElementById('adminPass').value;
        if (user === ADMIN_USER && pass === ADMIN_PASS) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            loginStatus.textContent = '';
            // Load new clients
            adminClients.innerHTML = '';
            for (let key in localStorage) {
                if (key.startsWith('client_')) {
                    const client = JSON.parse(localStorage.getItem(key));
                    const li = document.createElement('li');
                    li.textContent = `${client.name} (${client.email})`;
                    adminClients.appendChild(li);
                }
            }
            // Load orders
            adminOrders.innerHTML = '';
            for (let key in localStorage) {
                if (key.startsWith('client_')) {
                    const client = JSON.parse(localStorage.getItem(key));
                    client.orders.forEach(order => {
                        const li = document.createElement('li');
                        li.textContent = `${client.name}: ${order}`;
                        adminOrders.appendChild(li);
                    });
                }
            }
            // Load messages
            adminMessages.innerHTML = '';
            for (let key in localStorage) {
                if (key.startsWith('clientMessage_')) {
                    const msg = JSON.parse(localStorage.getItem(key));
                    const li = document.createElement('li');
                    li.textContent = `${msg.name} (${msg.email}): ${msg.message}`;
                    adminMessages.appendChild(li);
                }
            }
        } else {
            loginStatus.textContent = 'Invalid credentials!';
        }
    });

    window.logoutAdmin = function() {
        dashboard.style.display = 'none';
        loginForm.style.display = 'block';
        loginStatus.textContent = 'Logged out.';
    };
});
